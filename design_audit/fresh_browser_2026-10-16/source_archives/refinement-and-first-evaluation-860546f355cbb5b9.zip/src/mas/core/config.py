"""Layered run settings (design §14.1): one resolved configuration per run, with provenance.

Settings are flat dotted keys with a declared type and range, so that layering,
validation and provenance need no schema classes. Layers, lowest precedence first:

    code defaults -> preset -> ./mas.toml -> profile -> MAS__SECTION__KEY env -> --set k=v

The command line deliberately outranks the environment: a run-time override that an
environment variable could silently win over is a known source of unreproducible runs.

`providers` and `roles` stay free-form tables (they are model bindings, not scalars)
and are merged table-by-table in the same layer order.

The resolved values are hashed; `layer_record()` says which layer produced each value,
so a run can be replayed and a surprising number can be traced to its source.
"""

from __future__ import annotations

import os
import tomllib
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from .canonical import sha256_hex

LAYERS = ("default", "preset", "project", "profile", "environment", "override")

ENV_PREFIX = "MAS__"
PROJECT_FILE = "mas.toml"
PROFILE_DIR = Path.home() / ".config" / "mas" / "profiles"


class ConfigError(ValueError):
    """A setting that is unknown, mistyped, out of range, or inconsistent with another."""


@dataclass(frozen=True)
class Setting:
    default: Any
    doc: str
    minimum: float | None = None
    maximum: float | None = None
    choices: tuple[Any, ...] | None = None
    unit: str = ""
    const_id: str | None = None   # registered as a constant when it can affect a published verdict
    item_type: type | None = None  # for list settings


def _s(default, doc, **kw) -> Setting:
    return Setting(default, doc, **kw)


# --- the settings -------------------------------------------------------------------
# Every setting here is read by the code; a setting nothing reads would mislead whoever changes it.

SETTINGS: dict[str, Setting] = {
    # literature breadth and depth
    "search.sources": _s(["europepmc", "pubmed", "bookshelf", "wikibooks", "wikipedia", "uploads"],
                         "evidence sources to query (see `mas sources list`); sources not set up are skipped and recorded",
                         item_type=str),
    "sources.cache_dir": _s("", "where synced books and downloaded reference data are kept (empty: ~/.cache/mas)"),
    "sources.replay_run_ids": _s([], "ordered completed runs whose exact successful tool results may be reused; original provenance is retained", item_type=str),
    "sources.pubchem_record_projection": _s(False, "read additional descriptors from the same recorded PubChem rows, preserving source artifacts and retrieval dates"),
    "sources.upload_dir": _s("", "folder of documents you supply, with a manifest.toml (empty: STORE/uploads)"),
    "search.breadth": _s(4, "queries generated per dimension per round", minimum=1, maximum=20, unit="queries",
                         const_id="const_search_breadth"),
    "search.depth": _s(2, "follow-up search rounds after the first", minimum=1, maximum=6, unit="rounds",
                       const_id="const_search_depth"),
    "search.breadth_decay": _s(0.5, "factor applied to breadth at each follow-up round", minimum=0.1, maximum=1.0),
    "search.results_per_query": _s(20, "hits requested per query", minimum=1, maximum=200, unit="records"),
    "search.max_records_screened": _s(300, "upper bound on records screened per dimension", minimum=10, maximum=5000,
                                      unit="records", const_id="const_search_max_records"),
    "search.saturation_stop": _s(0.10, "stop a dimension when the share of newly relevant records falls below this",
                                 minimum=0.0, maximum=1.0, unit="fraction", const_id="const_search_saturation_stop"),
    "search.date_to": _s("", "evidence cutoff date (YYYY-MM-DD, empty for no bound)"),
    # WHY volume is named rather than numeric: the owner asked for a way to say how much to read, and
    # the useful observation from the 14 October runs is that raising the document ceiling did nothing
    # -- `--preset deep` allows 200 documents per dimension and enumerate made 19 reader calls, because
    # each dimension stops when newly-relevant records fall below `search.saturation_stop`. Reading
    # more means letting a dimension keep going past that point AND giving it more places to look, so
    # these bands move the saturation threshold and the screening width together. They are ceilings
    # and floors on effort, not targets: a dimension that saturates honestly stops early, and padding
    # a run to reach a number buys documents nobody should be reading.
    "search.volume": _s("mid", "how much literature a dimension reads before it stops",
                        choices=("low", "mid", "high", "xhigh")),
    "textbook.volume": _s("mid", "how many synced books a dimension draws on",
                          choices=("low", "mid", "high", "xhigh")),
    # reading
    "read.max_papers_full_read": _s(40, "documents read in full per dimension", minimum=1, maximum=500,
                                    unit="documents", const_id="const_read_max_documents"),
    "read.max_papers_per_candidate": _s(2, "documents read for one candidate's literature criteria", minimum=1,
                                        maximum=50, unit="documents", const_id="const_read_max_candidate_documents"),
    "read.max_content_chars": _s(60000, "characters of a document offered to the reader", minimum=1000,
                                 maximum=500000, unit="characters"),
    # the predicted-property panel (`adapters/predict/admet.py`). No const_id: it says where the
    # predictor is installed, not what it computes, and every predicted value records the package
    # version it came from (`data_version`), so a run's numbers stay identifiable without it.
    "predict.python": _s("", "interpreter of the environment that holds the ADMET predictor (empty: "
                             "$MAS_ADMET_PYTHON, else an `admet-env` beside the checkout)"),
    # The two floors `adjudication`'s `predictor_boundary_adopted` route reads before it lets a
    # classifier's own decision boundary gate (`adjudication.MIN_GATING_AUROC`, `MIN_GATING_R2`).
    # They carry a `const_id` because they decide whether a criterion scores at all, which is as
    # verdict-affecting as a cutoff: the same rule bound to the same endpoint gates under one value
    # of these and is demoted to a preference under another.
    "predict.min_gate_auroc": _s(0.70, "held-out AUROC a classification endpoint needs before a rule may gate on "
                                       "its decision boundary", minimum=0.5, maximum=1.0, unit="auroc",
                                 const_id="const_predict_min_gate_auroc"),
    "predict.min_gate_r2": _s(0.50, "held-out R^2 a regression endpoint needs before a rule may gate on a bound "
                                    "of its own", minimum=0.0, maximum=1.0, unit="r2",
                              const_id="const_predict_min_gate_r2"),
    # how much a value has to rest on before it is scored
    # WHY this is a setting and not a fixed rule: it buys support by discarding evidence, and which of the
    # two a run needs is the operator's call. One admitted claim is enough for a literature cell today, so a
    # single unrefused mis-extraction still decides a value -- measured on the two-candidate run of 14
    # October 2026, where the attribution guard refuses 48% of numeric literature claims and 9 of the 13
    # cells that still carry a value rest on one document, one of them on the comparator arm of a two-arm
    # comparison inside a span-verified quote. At 2 that run keeps 4 of those 13 cells, all 4 on the same
    # candidate. The default is 1 so that nothing changes until someone decides to pay that price
    # (`assessor.source_document_shortfall`).
    "evidence.min_source_documents": _s(1, "distinct source documents a literature criterion needs before its "
                                           "cell carries a value", minimum=1, maximum=10, unit="documents",
                                        const_id="const_evidence_min_source_documents"),
    # criteria pool workflow
    "criteria.inner_iterations": _s(3, "filter/distill/refine/merge passes within one round", minimum=1, maximum=10,
                                    unit="iterations", const_id="const_criteria_inner_iterations"),
    # WHY the order ends with merge, and why this default is the one that matters: `filter` moves every
    # item with a validator or critic finding to `needs_refine`, `distill` and `merge` read only
    # `candidate`, and `refine` is what returns a repaired item to `candidate`. With merge third it sees
    # whatever filter happened not to flag. 2bc0abd corrected `derivation_run.DEFAULT_STAGES` for that
    # reason -- but the CLI passes `stage_names=tuple(settings["criteria.stages"])`, so this list wins and
    # this list still said `merge` third. Measured on the clean derivation of 14 October 2026, after that
    # fix: `filter` sent 49 of 59 items to `needs_refine`, `merge` then reported
    # `{groups: 0, merged: 0}`, and `refine` repaired 29 afterwards -- the defect the fix was supposed to
    # remove, surviving in production because the regression test called `derive_iterative` directly and
    # never went through the settings layer. `test_the_configured_stage_order_is_the_one_the_library_
    # defaults_to` now pins the two together so they cannot drift apart again.
    "criteria.stages": _s(["filter", "distill", "refine", "merge"], "pool stages run each iteration, in order",
                          item_type=str),
    "criteria.max_refines": _s(2, "refinement attempts before an item waits for the next round", minimum=1, maximum=5,
                               unit="attempts", const_id="const_criteria_max_refines"),
    "criteria.merge_overlap": _s(0.35, "word overlap at which two candidates are offered to the adjudicator to merge",
                                 minimum=0.0, maximum=1.0, unit="fraction", const_id="const_criteria_merge_overlap"),
    "criteria.stall_rounds": _s(2, "unchanged iterations that end a round early", minimum=1, maximum=5,
                                unit="iterations", const_id="const_criteria_stall_rounds"),
    # sweep
    "assess.max_candidates": _s(0, "candidates assessed; 0 means the whole universe", minimum=0, maximum=1000000),
    "assess.workers": _s(1, "candidates whose literature is read and ruled on at once", minimum=1,
                         maximum=32),
    # The calibration guard's one number (`assessor.calibration_guard`, applied by
    # `controller._calibration_guard`). WHY 0.90 by default: the guard is meant to catch a gate that
    # has stopped discriminating, not to second-guess a selective one, and at 0.90 fewer than one in
    # ten of the candidates that clear the task's own mandated criteria survive the gate -- at which
    # point the gate is making a statement about the population rather than about its members.
    # Measured on the manuscript universe with the predicted-toxicity panel at the model's 0.5 line:
    # a composite toxicity gate removes 100% of the 116 approved or phase-3 kinase inhibitors and
    # DILI alone 99.1%, both demoted here; hERG alone removes 88.8% and is not, which is deliberate
    # -- a gate that leaves one candidate in nine is still a gate, and a default that demoted it
    # would be deciding on the operator's behalf how selective a screen may be. A run that wants the
    # stricter reading sets this to 0.80 and gets it, with the share recorded either way.
    "assess.max_reference_exclusion_share": _s(
        0.90, "share of the candidates clearing the task's mandated criteria that a hard exclusion may remove "
              "before it is demoted to a preference for the run", minimum=0.0, maximum=1.0, unit="fraction",
        const_id="const_assess_max_reference_exclusion_share"),
    # ranking
    "rank.method": _s("weighted_preference", "how the leaderboard score is produced",
                      choices=("weighted_preference", "symbolic_expression")),
    "rank.coverage_floor": _s(0.5, "minimum share of scoring inputs a candidate needs to be ranked",
                              minimum=0.0, maximum=1.0, unit="fraction", const_id="const_ranking_coverage_floor"),
    # The floor over the task's *own* criteria, beside the one above, which is over scoring inputs of
    # every kind. WHY 1.0 by default: the task stated each mandated criterion as a requirement, so a
    # candidate it cannot be answered for is not a candidate the task's objective has been measured
    # on. Measured on the 14 October board, where the two floors come apart: 4 of its 9 criteria are
    # structural descriptors available for every compound, so a candidate with those four and one of
    # the five required receptors clears `rank.coverage_floor` at 0.5 -- and the top four entries
    # each had one receptor of five, with an anthelmintic at rank 4, above candidates assessed on all
    # five. A run that wants the looser reading sets this to 0.6 and gets it, with the number
    # recorded on the snapshot either way.
    "rank.mandated_coverage_floor": _s(
        1.0, "share of the criteria the task itself mandates that a candidate must have answered to be ranked",
        minimum=0.0, maximum=1.0, unit="fraction", const_id="const_mandated_coverage_floor"),
    "rank.top_n": _s(25, "rows shown by default on the leaderboard", minimum=1, maximum=1000),
    "sr.mode": _s("off", "what the symbolic regression models",
                  choices=("off", "potency", "leaderboard_score", "both")),
    "sr.generations": _s(4, "proposal/diagnostic rounds offered to the model", minimum=1, maximum=12,
                         unit="generations", const_id="const_sr_generations"),
    "sr.max_terms": _s(4, "terms allowed in an expression", minimum=1, maximum=8, unit="terms",
                       const_id="const_sr_max_terms"),
    "sr.min_improvement": _s(0.02, "holdout gain over the weighted-preference baseline required for adoption",
                             minimum=0.0, maximum=1.0, const_id="const_sr_min_improvement"),
    "sr.min_training_rows": _s(12, "usable rows below which coefficients come from cited priors instead of a fit",
                               minimum=2, maximum=10000, unit="rows", const_id="const_sr_min_training_rows"),
    "sr.select_share": _s(0.25, "share of candidates held back for comparing generations", minimum=0.05,
                          maximum=0.45, unit="fraction", const_id="const_sr_select_share"),
    "sr.holdout_share": _s(0.25, "share of candidates touched once, for the adoption decision", minimum=0.05,
                           maximum=0.45, unit="fraction", const_id="const_sr_holdout_share"),
    "sr.ridge": _s(0.1, "shrinkage toward the model's declared prior", minimum=0.0, maximum=100.0,
                   const_id="const_sr_ridge"),
    "sr.complexity_penalty": _s(0.01, "score deducted per term and per depth level", minimum=0.0, maximum=1.0,
                                const_id="const_sr_complexity_penalty"),
    "sr.max_condition": _s(1e8, "design-matrix condition number above which a fit is refused", minimum=1.0,
                           maximum=1e15, const_id="const_sr_max_condition"),
    # budget
    "budget.usd_max": _s(20.0, "provider spend allowed for one run", minimum=0.0, maximum=100000.0, unit="USD",
                         const_id="const_budget_usd_max"),
    "budget.warn_at": _s(0.8, "share of the cap at which the run warns", minimum=0.1, maximum=1.0, unit="fraction"),
    "budget.on_exhaust": _s("warn_continue", "what happens when the cap is reached",
                            choices=("warn_continue", "finalize_partial", "ask", "abort")),
    "budget.llm_turns": _s(0, "model calls allowed; 0 means no limit", minimum=0, maximum=1000000),
    "budget.tool_calls": _s(0, "tool calls allowed; 0 means no limit", minimum=0, maximum=1000000),
    # concurrency
    # The clean derivation's enumerate stage spent roughly 10 minutes on 16 reader and 8 retriever
    # calls, every one sequential, at a per-call price that made wall-clock the binding constraint
    # rather than spend. A worker count carries no `const_id`: `evidence.read_literature` collects a
    # candidate's claims positionally and concatenates them in the documents' own order, and every
    # cell of that candidate is assessed against the finished reading, so raising this cannot move a
    # value, a verdict or a digest, and registering it as verdict-affecting would say it can.
    # It multiplies with `assess.workers`: N candidates each reading M documents is N*M in flight.
    # Measured on a synthetic eight-document cell at 0.25 s per extraction: 2.40 s at 1 worker,
    # 0.81 s at 4, 0.71 s at 8. The 0.40 s that does not shrink is the per-document journal and
    # artifact writing, which serializes on the store write lock -- so past roughly 8 the ceiling
    # is the store, not the setting, which is why it stops at 16.
    "concurrency.read_workers": _s(1, "documents read and claim-extracted at once within one cell",
                                   minimum=1, maximum=16, unit="workers"),
    # interaction
    "interaction.mode": _s("checkpoint", "how often the run stops for a person",
                           choices=("autonomous", "checkpoint", "interactive")),
    "interaction.checkpoints": _s(["criteria_final", "pre_rank"], "points at which a checkpoint run pauses",
                                  item_type=str),
    "interaction.autonomous_adjudication": _s(False, "let `mas review adjudicate` resolve review queue items "
                                                     "without a person (recorded as machine adjudications, never "
                                                     "as expert decisions); interaction.mode = autonomous turns "
                                                     "it on"),
    # run
    "evaluation.mode": _s("staged", "evaluate all cells or skip after a verified hard failure", choices=("staged", "full")),
    "qualification.policy": _s("qualification_first_v1", "qualification and scoring policy",
                                  choices=("qualification_first_v1", "legacy")),
    "evidence.mode": _s("existing_only", "reuse fixed facts or allow retrieval", choices=("existing_only", "retrieve")),
    "run.seed": _s(0, "sweep seed; also seeds the symbolic-regression splits", minimum=0, maximum=2**31 - 1),
}

CHECKPOINTS = ("search_plan", "criteria_final", "pre_rank", "report")

PRESETS: dict[str, dict[str, Any]] = {
    "quick": {
        "search.breadth": 2, "search.depth": 1, "search.max_records_screened": 60,
        "read.max_papers_full_read": 10,
        "criteria.inner_iterations": 1,
        "sr.generations": 2, "budget.usd_max": 2.0, "interaction.mode": "autonomous",
        "interaction.checkpoints": [],
    },
    "standard": {},
    "deep": {
        "search.breadth": 8, "search.depth": 4, "search.max_records_screened": 1500,
        "read.max_papers_full_read": 200,
        "criteria.inner_iterations": 6,
        "sr.generations": 8, "budget.usd_max": 100.0,
    },
}


# --- resolution ----------------------------------------------------------------------

def _flatten(table: dict[str, Any], prefix: str = "") -> dict[str, Any]:
    """Flatten a TOML table into dotted keys, stopping at list and scalar values."""
    flat: dict[str, Any] = {}
    for key, value in table.items():
        dotted = f"{prefix}{key}"
        if isinstance(value, dict):
            flat.update(_flatten(value, f"{dotted}."))
        else:
            flat[dotted] = value
    return flat


def _coerce(key: str, raw: Any) -> Any:
    """Coerce a string from the environment or the command line to the setting's type."""
    setting = SETTINGS[key]
    want = type(setting.default)
    if not isinstance(raw, str) or want is str:
        return raw
    text = raw.strip()
    if want is bool:
        if text.lower() in ("true", "yes", "1", "on"):
            return True
        if text.lower() in ("false", "no", "0", "off"):
            return False
        raise ConfigError(f"{key}: {raw!r} is not a true/false value")
    if want is list:
        return [part.strip() for part in text.split(",") if part.strip()]
    try:
        return want(text) if want is not float else float(text)
    except ValueError:
        raise ConfigError(f"{key}: {raw!r} is not a {want.__name__}") from None


def _check(key: str, value: Any) -> Any:
    setting = SETTINGS[key]
    want = type(setting.default)
    if want is float and isinstance(value, int) and not isinstance(value, bool):
        value = float(value)
    if want is bool and not isinstance(value, bool):
        raise ConfigError(f"{key}: expected true/false, got {value!r}")
    if want is not bool and isinstance(value, bool):
        raise ConfigError(f"{key}: expected {want.__name__}, got a boolean")
    if not isinstance(value, want):
        raise ConfigError(f"{key}: expected {want.__name__}, got {type(value).__name__}")
    if setting.item_type is not None:
        bad = [v for v in value if not isinstance(v, setting.item_type)]
        if bad:
            raise ConfigError(f"{key}: list entries must be {setting.item_type.__name__}; got {bad!r}")
    if setting.choices is not None and value not in setting.choices:
        raise ConfigError(f"{key}: {value!r} is not one of {list(setting.choices)}")
    if setting.minimum is not None and value < setting.minimum:
        raise ConfigError(f"{key}: {value} is below the minimum {setting.minimum}")
    if setting.maximum is not None and value > setting.maximum:
        raise ConfigError(f"{key}: {value} is above the maximum {setting.maximum}")
    return value


def _env_overrides(environ: dict[str, str]) -> dict[str, Any]:
    out: dict[str, Any] = {}
    for name, raw in environ.items():
        if not name.startswith(ENV_PREFIX):
            continue
        key = name[len(ENV_PREFIX):].replace("__", ".").lower()
        if key not in SETTINGS:
            raise ConfigError(f"{name}: no setting named {key!r}")
        out[key] = raw
    return out


def parse_overrides(pairs: list[str] | tuple[str, ...]) -> dict[str, Any]:
    """Parse `--set key=value` arguments."""
    out: dict[str, Any] = {}
    for pair in pairs or ():
        if "=" not in pair:
            raise ConfigError(f"--set expects key=value, got {pair!r}")
        key, raw = pair.split("=", 1)
        key = key.strip()
        if key not in SETTINGS:
            raise ConfigError(f"no setting named {key!r}")
        out[key] = raw
    return out


@dataclass
class Config:
    values: dict[str, Any]
    sources: dict[str, str]
    providers: dict[str, Any] = field(default_factory=dict)
    roles: dict[str, str] = field(default_factory=dict)
    preset: str = "standard"
    profile: str | None = None

    def __getitem__(self, key: str) -> Any:
        return self.values[key]

    def get(self, key: str, default: Any = None) -> Any:
        return self.values.get(key, default)

    def section(self, name: str) -> dict[str, Any]:
        prefix = f"{name}."
        return {k[len(prefix):]: v for k, v in self.values.items() if k.startswith(prefix)}

    def hash(self) -> str:
        return sha256_hex({"values": self.values, "providers": self.providers, "roles": self.roles})

    def layer_record(self) -> dict[str, Any]:
        """Provenance artifact: every value with the layer that produced it."""
        return {"preset": self.preset, "profile": self.profile, "config_hash": self.hash(),
                "settings": [{"key": k, "value": self.values[k], "layer": self.sources[k],
                              "unit": SETTINGS[k].unit, "doc": SETTINGS[k].doc} for k in sorted(self.values)]}

    def registered_constants(self) -> list[tuple[str, Any, str]]:
        """Settings that can affect a published verdict, as (const_id, value, unit)."""
        return [(SETTINGS[k].const_id, self.values[k], SETTINGS[k].unit)
                for k in sorted(self.values) if SETTINGS[k].const_id]

    def non_default(self) -> dict[str, Any]:
        return {k: v for k, v in sorted(self.values.items()) if self.sources[k] != "default"}


def _load_toml(path: Path) -> dict[str, Any]:
    try:
        return tomllib.loads(path.read_text(encoding="utf-8"))
    except (OSError, tomllib.TOMLDecodeError) as error:
        raise ConfigError(f"{path}: {error}") from None


def resolve(*, preset: str = "standard", project_file: str | os.PathLike | None = PROJECT_FILE,
            profile: str | None = None, profile_dir: str | os.PathLike = PROFILE_DIR,
            overrides: dict[str, Any] | None = None, environ: dict[str, str] | None = None,
            extra_tables: dict[str, dict[str, Any]] | None = None) -> Config:
    """Resolve the layers into one validated configuration."""
    if preset not in PRESETS:
        raise ConfigError(f"unknown preset {preset!r}; known presets are {sorted(PRESETS)}")
    values = {key: setting.default for key, setting in SETTINGS.items()}
    sources = {key: "default" for key in SETTINGS}
    providers: dict[str, Any] = {}
    roles: dict[str, str] = {}

    def apply(flat: dict[str, Any], layer: str) -> None:
        for key, raw in flat.items():
            if key not in SETTINGS:
                raise ConfigError(f"{layer}: no setting named {key!r}")
            values[key] = _check(key, _coerce(key, raw))
            sources[key] = layer

    def apply_tables(table: dict[str, Any], layer: str) -> None:
        for name, spec in (table.get("providers") or {}).items():
            providers[name] = dict(spec)
        roles.update(table.get("roles") or {})

    apply({k: v for k, v in PRESETS[preset].items()}, "preset")
    for layer, path in (("project", Path(project_file) if project_file else None),
                        ("profile", Path(profile_dir) / f"{profile}.toml" if profile else None)):
        if path is None:
            continue
        if not path.exists():
            if layer == "profile":
                raise ConfigError(f"no profile at {path}")
            continue
        table = _load_toml(path)
        apply_tables(table, layer)
        apply(_flatten({k: v for k, v in table.items() if k not in ("providers", "roles")}), layer)
    for layer, table in (extra_tables or {}).items():
        apply_tables(table, layer)
        apply(_flatten({k: v for k, v in table.items() if k not in ("providers", "roles")}), layer)
    apply(_env_overrides(environ if environ is not None else dict(os.environ)), "environment")
    apply(dict(overrides or {}), "override")
    if values["interaction.mode"] == "autonomous" and sources["interaction.autonomous_adjudication"] == "default":
        # Choosing the autonomous mode is choosing to run with nobody to ask, so the switch that lets
        # the queue be resolved without a person follows it. It is implied, never forced: a layer that
        # sets it explicitly keeps its value, including `false` alongside the autonomous mode.
        values["interaction.autonomous_adjudication"] = True
        sources["interaction.autonomous_adjudication"] = sources["interaction.mode"]

    config = Config(values, sources, providers, roles, preset=preset, profile=profile)
    validate(config)
    return config


def validate(config: Config) -> None:
    """Checks that span more than one setting."""
    v = config.values
    if v["sr.select_share"] + v["sr.holdout_share"] > 0.7:
        raise ConfigError("sr.select_share + sr.holdout_share must leave at least 30% of candidates for fitting")
    if v["rank.method"] == "symbolic_expression" and v["sr.mode"] == "off":
        raise ConfigError("rank.method = symbolic_expression needs sr.mode set to potency, leaderboard_score or both")
    unknown = [c for c in v["interaction.checkpoints"] if c not in CHECKPOINTS]
    if unknown:
        raise ConfigError(f"interaction.checkpoints: unknown {unknown}; known checkpoints are {list(CHECKPOINTS)}")
    if v["interaction.mode"] == "autonomous" and v["interaction.checkpoints"]:
        raise ConfigError("interaction.mode = autonomous cannot list checkpoints; clear interaction.checkpoints "
                          "or choose the checkpoint mode")
    if v["interaction.autonomous_adjudication"] and v["interaction.checkpoints"]:
        raise ConfigError("interaction.autonomous_adjudication cannot be on while interaction.checkpoints lists "
                          f"{v['interaction.checkpoints']}: a run that stops for a person at a checkpoint has a "
                          "person to ask, and resolving the queue without asking them would make the checkpoint "
                          "a formality; clear interaction.checkpoints or turn the setting off")
    from mas.adapters.literature import registry
    try:
        registry.resolve(v["search.sources"])
    except registry.SourceRefused as error:
        raise ConfigError(f"search.sources: {error}") from None
    if config.roles:
        missing = sorted(set(config.roles.values()) - set(config.providers))
        if missing:
            raise ConfigError(f"roles bound to providers that are not configured: {missing}")


# --- recording and estimating --------------------------------------------------------

def register_constants(core, config: Config, *, by: dict[str, Any], stream_id: str | None = None) -> list[str]:
    """Register the verdict-affecting settings as constants (design §8.4) before a run uses them."""
    from . import constants
    registered = []
    for const_id, value, unit in config.registered_constants():
        kwargs = {"unit": unit or "count", "scope": "core_policy",
                  "cutoff_basis": "operator_configuration", "set_by": by}
        if stream_id is not None:
            kwargs["stream_id"] = stream_id
        constants.register(core, const_id, value, **kwargs)
        registered.append(const_id)
    return registered


def estimate(config: Config, *, dimensions: int = 1, candidates: int = 0) -> dict[str, Any]:
    """Volume and cost estimate for `--dry-run`: no network, no model calls."""
    v = config.values
    breadth, queries = float(v["search.breadth"]), 0.0
    for _ in range(v["search.depth"]):
        queries += max(1.0, breadth)
        breadth *= v["search.breadth_decay"]
    queries *= dimensions
    records = min(queries * v["search.results_per_query"], v["search.max_records_screened"] * dimensions)
    documents = min(records, v["read.max_papers_full_read"] * dimensions)
    # one query-planning call and one extraction call per document, per inner iteration pass
    reads = documents * v["criteria.inner_iterations"]
    pool_calls = dimensions * (1 + len(v["criteria.stages"]) * v["criteria.inner_iterations"])
    sr_calls = 0 if v["sr.mode"] == "off" else v["sr.generations"] * (2 if v["sr.mode"] == "both" else 1)
    llm_calls = int(queries + reads + pool_calls + sr_calls)
    sweep = candidates or v["assess.max_candidates"]
    return {"search_queries": int(queries), "records_screened": int(records), "documents_read": int(documents),
            "llm_calls": llm_calls, "pool_stage_calls": int(pool_calls), "symbolic_regression_calls": int(sr_calls),
            "candidates_assessed": int(sweep),
            "note": "model calls are an upper bound: caching, saturation stop and stall detection all reduce them",
            "budget_usd_max": v["budget.usd_max"], "on_exhaust": v["budget.on_exhaust"]}
