"""Durable workflow review attempts; unresolved is reusable work, never an approval."""
from __future__ import annotations

import json
from typing import Any

from . import adjudication, criteria, review, task
from .canonical import sha256_hex
from .clock import utc_now
from .derivation import _claims_block
from .journal import actor

RECORDER = actor('controller', 'workflow-review-attempts', 'controller')


def _events(core, task_id, kind, after=0):
    return [json.loads(row[0]) for row in core.store.db.execute(
        'SELECT body FROM events WHERE stream_id=? AND event_type=? AND seq>? ORDER BY seq',
        (task_id, kind, after))]


def _version(core, task_id, kind, ref):
    base, version = ref.rsplit('@v', 1)
    row = core.store.db.execute("SELECT json_extract(body,'$.payload.artifact_id') FROM events "
        "WHERE stream_id=? AND event_type='criterion.version_proposed' "
        "AND json_extract(body,'$.payload.kind')=? AND json_extract(body,'$.payload.id')=? "
        "AND json_extract(body,'$.payload.version')=? ORDER BY seq DESC LIMIT 1",
        (task_id, kind, base, int(version))).fetchone()
    if row is None:
        raise KeyError(ref)
    return core.artifacts.payload(row[0])


def _scope(core, item, roster, settings, qualification_policy):
    tid = item['stream_id']
    context = task.get(core, tid)
    rule = _version(core, tid, 'rule', item['subject']['id'])
    attribute = _version(core, tid, 'attribute', rule['attribute_ref'])
    claims = adjudication.cited_claims(core, tid, item, attribute)
    other = adjudication._cited_claims(core, tid, attribute, item, rule)
    bank = {claim['claim_id']: claim for claim in [*claims, *other]}
    policy = qualification_policy or (settings or {}).get('qualification.policy', 'legacy')
    marker = adjudication.independence(roster) if roster is not None else None
    inputs = {'method': 'workflow-review-attempt-v1', 'task_ref': f"{tid}@v{context['version']}",
        'task_sha256': sha256_hex(context), 'item_id': item['item_id'], 'subject': item['subject'],
        'rule_sha256': sha256_hex(rule), 'attribute_ref': rule['attribute_ref'],
        'attribute_sha256': sha256_hex(attribute), 'inspection_bundle': item.get('inspection_bundle'),
        'claims': [{'claim_id': key, 'sha256': sha256_hex(value)} for key, value in sorted(bank.items())],
        'qualification_policy': policy, 'reviewer': marker,
        'review_settings': {key: value for key, value in (settings or {}).items()
                            if key in ('predict.min_gate_auroc', 'predict.min_gate_r2')}}
    return sha256_hex(inputs), inputs, context, rule, attribute, claims


def _answer(trace):
    text = trace.get('final_text') or ''
    try:
        result = json.loads(text)
    except (ValueError, TypeError):
        try:
            result = json.JSONDecoder().raw_decode(text[text.index('{'):])[0]
        except (ValueError, TypeError):
            return None
    return result if isinstance(result, dict) else None


def _legacy_unresolved(core, item, inputs, context, rule, attribute, claims):
    """Recover only a completed exact dispute response whose pending result is deterministic.

    Legacy successful decisions already close the queue item. Unsupported/ambiguous legacy
    applications are not guessed. This deliberately never reads an unfinished request's trace.
    """
    if inputs['qualification_policy'] != 'qualification_first_v1' \
            or context.get('qualification_policy') != 'qualification_first_v1' or not inputs['reviewer']:
        return None
    route, _ = adjudication.route_of(rule, attribute, context, item,
        adjudication._cited_claims(core, item['stream_id'], attribute, item, rule), {})
    if route != 'dispute_adjudicated':
        return None
    view = adjudication._dispute_view(attribute, rule)
    # Original traces omit the queue/rule IDs. Require a unique binding to the complete versioned
    # criterion view, in addition to the exact prompt/claims/findings below.
    matching = []
    for other in review.items(core, [item['stream_id']]).values():
        if other['subject'].get('kind') != 'rule_version':
            continue
        candidate_rule = _version(core, item['stream_id'], 'rule', other['subject']['id'])
        candidate_attr = _version(core, item['stream_id'], 'attribute', candidate_rule['attribute_ref'])
        if adjudication._dispute_view(candidate_attr, candidate_rule) == view:
            matching.append(other['item_id'])
    if matching != [item['item_id']]:
        return None
    content = (f"Objective: {context['objective_text']}\n\n"
        f"Criterion under dispute:\n{json.dumps(view, ensure_ascii=False, indent=1)}\n\n"
        f"The critic's open findings:\n"
        f"{json.dumps(item['inspection_bundle']['open_critic_findings'], ensure_ascii=False, indent=1)}\n\n"
        f"Cited claims ({len(claims)}):\n{_claims_block(claims)}")
    versions = _events(core, item['stream_id'], 'task.version_recorded')
    for finished in _events(core, item['stream_id'], 'agent.finished'):
        payload = finished['payload']
        if payload.get('role') != 'adjudicator' or payload.get('schema_ok') is not True \
                or payload.get('outcome') != 'ok' or payload.get('reply_truncated'):
            continue
        prior_versions = [event for event in versions if event['seq'] < finished['seq']]
        if not prior_versions or prior_versions[-1]['payload']['version'] != context['version']:
            continue
        expected_actor = inputs['reviewer']
        if finished['actor'].get('version') != expected_actor['adjudicator_model_id'] \
                or finished['actor'].get('model_family') != expected_actor['adjudicator_family']:
            continue
        envelope = core.artifacts.get(payload['trace_blob'])
        if envelope['kind'] != 'trace':
            continue
        trace, request = envelope['payload'], envelope['payload'].get('request') or {}
        if trace.get('outcome') != 'ok' or trace.get('truncated') or trace.get('schema_problems') \
                or request.get('role') != 'adjudicator' \
                or request.get('system') != adjudication.ADJUDICATOR_SYSTEM \
                or request.get('response_schema') != adjudication.ADJUDICATION_SCHEMA \
                or request.get('messages') != [{'role': 'user', 'content': content}] \
                or request.get('metadata') != {'question': 'adjudicate a proposer/critic dispute'} \
                or request.get('max_tokens') != 4000 or request.get('temperature') != 0.0:
            continue
        answer = _answer(trace)
        if not answer:
            return None
        verdict = answer.get('verdict')
        if verdict == 'uphold_objection':
            reason = "the critic's finding stands, so the criterion does not score as proposed"
        elif verdict == 'cannot_resolve':
            reason = 'the adjudicator could not settle the dispute on the evidence before it'
        elif verdict == 'revise':
            _, reason, _ = adjudication._apply_revision(rule, answer.get('revised_rule') or {}, attribute, claims=claims)
            if not reason:
                return None  # a potentially applicable legacy revision is not silently applied or approved
        else:
            return None
        # Preserve the earliest completed exact response; do not choose among repeated verdicts.
        return {'outcome': 'unresolved', 'reason_text': 'criterion remains pending under qualification_first_v1: ' + reason,
            'reason_origin': 'deterministic_reconstruction_from_completed_dispute_trace',
            'model_verdict': verdict, 'model_reasoning': answer.get('reasoning'),
            'source_agent_records': [{'finished_seq': finished['seq'], 'request_id': payload['request_id'],
                'trace_ref': payload['trace_blob'], 'recorded_at': finished['recorded_at'],
                'cost_usd': payload.get('cost_usd'), 'cost_status': payload.get('cost_status')}],
            'source_kind': 'legacy_completed_trace', 'reused': True}
    return None


def _save(core, item, key, inputs, result):
    record = dict(result, review_attempt_key=key, input=inputs, completed=True, recorded_at=utc_now(),
                  task_id=item['stream_id'], item_id=item['item_id'], rule_ref=item['subject']['id'],
                  attribute_ref=inputs['attribute_ref'], creates_approval=False)
    ref = core.artifacts.put('review_attempt', record)
    core.journal.append(item['stream_id'], 'decision.recorded', actor=RECORDER,
        ids={'task_id': item['stream_id'], 'review_request_id': item['item_id']},
        payload={'record_kind': 'review_attempt', 'review_attempt_key': key, 'artifact_id': ref,
                 'item_id': item['item_id'], 'outcome': record['outcome']},
        artifact_links=[{'kind': 'review_attempt', 'id': ref}])
    return dict(record, attempt_ref=ref)


def review_once(core, item, *, roster=None, budget=None, settings=None, qualification_policy=None):
    """Complete or explicitly reuse one workflow review attempt. Never resolves an unresolved item."""
    key, inputs, context, rule, attribute, claims = _scope(core, item, roster, settings, qualification_policy)
    row = core.store.db.execute("SELECT body FROM events WHERE stream_id=? AND event_type='decision.recorded' "
        "AND json_extract(body,'$.payload.record_kind')='review_attempt' "
        "AND json_extract(body,'$.payload.review_attempt_key')=? ORDER BY seq DESC LIMIT 1",
        (item['stream_id'], key)).fetchone()
    if row:
        source = json.loads(row[0])['payload']['artifact_id']
        prior = core.artifacts.payload(source)
        core.journal.append(item['stream_id'], 'decision.recorded', actor=RECORDER,
            ids={'task_id': item['stream_id'], 'review_request_id': item['item_id']},
            payload={'record_kind': 'review_attempt_reused', 'source_attempt_ref': source,
                     'review_attempt_key': key, 'item_id': item['item_id'], 'outcome': prior['outcome']})
        return dict(prior, attempt_ref=source, reused=True)
    legacy = _legacy_unresolved(core, item, inputs, context, rule, attribute, claims)
    if legacy is not None:
        return _save(core, item, key, inputs, legacy)
    start = core.journal.last_seq(item['stream_id'])
    try:
        decision = adjudication.adjudicate(core, item, roster=roster, budget=budget, settings=settings,
                                          qualification_policy=qualification_policy)
        result = {'outcome': 'resolved', 'reason_text': decision['reason_text'],
                  'decision_ref': decision['adjudication_id']}
    except adjudication.AdjudicationError as error:
        result = {'outcome': 'unresolved', 'reason_text': str(error)}
    # ModelError and InterruptedError propagate: a partial/failed request is not completed work.
    finished = [event for event in _events(core, item['stream_id'], 'agent.finished', start)
                if event['payload'].get('role') == 'adjudicator']
    started = [event for event in _events(core, item['stream_id'], 'agent.started', start)
               if event['payload'].get('role') == 'adjudicator']
    if {e['payload']['request_id'] for e in started} != {e['payload']['request_id'] for e in finished}:
        raise adjudication.AdjudicationError('review attempt has an unfinished request; it was not cached')
    result.update(source_kind='workflow_attempt', reason_origin='adjudicate_return_or_error', reused=False,
        source_agent_records=[{'finished_seq': event['seq'], 'request_id': event['payload']['request_id'],
            'trace_ref': event['payload'].get('trace_blob'), 'cost_usd': event['payload'].get('cost_usd'),
            'cost_status': event['payload'].get('cost_status')} for event in finished])
    return _save(core, item, key, inputs, result)
