"""Criterion derivation (design §5, §8.3; C7, C10): recall-first enumeration, proposal, critique, validation.

1. Enumerate per dimension: plan queries, search, read, and extract criterion-discovery
   claims (quotes checked) until `saturation_k` consecutive documents add no new
   attribute hint. Case-source documents are excluded from every catalog.
2. Propose: the proposer turns the discovered hints into attribute and rule proposals,
   each citing claim ids, with `expected_change` and `falsification_test`.
3. Validate deterministically: registry invariants, cited claims exist and are admitted,
   `source_stated_value` cutoffs rest on a cited value, the disclosed reference outcome is
   never named (reference-candidate scan).
4. Critique: a blind critic sees the proposals and the cited claims, never the proposer's
   rationale; its findings must reference claims or proposal fields.
5. Adjudicate deterministically: a proposal enters the registry as `proposed` (queued for
   expert confirmation) only if validation passes and the critic raised no blocking
   finding; one revision round is allowed; everything else is kept as considered-and-rejected.
"""

from __future__ import annotations

import json
from typing import Any

from . import assessor, bound_support, criteria, reading
from .clock import utc_now
from .journal import actor as make_actor
from .models import ModelError, ModelRequest, ModelRoster, call_role
from .runtime import Core

PROPOSAL_SCHEMA = {
    "type": "object", "required": ["proposals", "considered_and_rejected"],
    "properties": {
        "proposals": {"type": "array", "items": {"type": "object", "required": ["attribute", "rule", "supporting_claim_ids",
                                                                             "expected_change", "falsification_test"],
                                                 "properties": {"attribute": {"type": "object"}, "rule": {"type": "object"},
                                                                "supporting_claim_ids": {"type": "array", "items": {"type": "string"}},
                                                                "expected_change": {"type": "string"},
                                                                "falsification_test": {"type": "string"}}}},
        "considered_and_rejected": {"type": "array", "items": {"type": "object"}},
    },
}

CRITIQUE_SCHEMA = {
    "type": "object", "required": ["findings"],
    "properties": {"findings": {"type": "array", "items": {
        "type": "object", "required": ["proposal_index", "check", "verdict", "referent", "finding"],
        "properties": {"proposal_index": {"type": "integer"},
                       "check": {"type": "string", "enum": ["objective_conformance", "evidence_support",
                                                            "unit_applicability_consistency", "counter_evidence_considered",
                                                            "candidate_symmetric_scrutiny", "falsification_test_evaluated"]},
                       "verdict": {"type": "string", "enum": ["pass", "fail", "unknown"]},
                       "severity": {"type": "string", "enum": ["blocking", "material", "minor"]},
                       "referent": {"type": "string"}, "finding": {"type": "string"}}}}},
}

PROPOSER_SYSTEM = (
    "You propose screening criteria (attributes and rules) for an evidence-driven prioritization task. "
    "Work only from the objective, the constraints, and the claims provided (each has an id and a verbatim quote). "
    "Each proposal is one measurable attribute plus one rule. Rules are hard_exclusion (a candidate failing it is "
    "excluded) or preference (it ranks candidates). Prefer preference rules unless the objective, a constraint or "
    "the cited evidence makes the property a requirement. "
    # WHY the threshold instruction is this insistent: the earlier wording offered
    # `none_evidence_insufficient` as a co-equal option and the proposer took it every single time.
    # Measured on the manuscript registry: 39 of 40 promoted rules carry no cutoff at all, and the one
    # that does restates a task constraint, so the whole system held two literature-derived numbers --
    # both transform bounds. A criteria set of unbounded orderings cannot express a requirement, and
    # the thresholds it declines to state are exactly what a reviewer checks. The decision about
    # whether a number is supported belongs to `bound_support`, which sees the claim; a proposer that
    # pre-emptively declines to name one removes that judgement from the system entirely.
    "SET A CUTOFF WHENEVER A CITED CLAIM STATES A NUMBER THAT COULD SERVE AS ONE. Read every claim for "
    "quantities: a stated requirement, a reported range, a value an author calls optimal, adequate, "
    "acceptable or excessive. If a claim gives such a number, propose the cutoff with cutoff_basis "
    "source_stated_value, cite that claim, and declare a bound_support record saying which it is: "
    "states_decision_threshold when the passage proposes the number as a requirement, reports_measurement "
    "when it reports an observation, provides_heuristic when it offers a rule of thumb. Declaring it a "
    "measurement or a heuristic is not a weaker answer -- it is the honest one, and the record is what "
    "lets a reviewer judge the cutoff. Only use cutoff_basis none_evidence_insufficient when no cited "
    "claim states any number you could threshold on, and then say which quantity was missing in the "
    "rationale. Never invent a number that is not in a quote. "
    # WHY the proposer is told it may interpret: the honest declaration above used to end the story.
    # Measured on the clean derivation of 14 October 2026, 29 of 33 cutoffs came back
    # `reports_measurement` and 4 `provides_heuristic`, none `states_decision_threshold`, and one
    # criterion of 35 carried a cutoff at all -- so no derived criterion could exclude anything, and
    # against the 11 sealed historical attributes the recovery measurement read exact 0 / 11 with all
    # 5 near matches differing on the threshold facet. A proposer that may not state the step from a
    # measurement to a bound has only two moves left: invent a number, or decline to have one.
    "WHERE A CITED PASSAGE REPORTS A MEASUREMENT A SCREENING DECISION CAN DEFENSIBLY REST ON, PROPOSE "
    "THE CUTOFF AND DECLARE THE INTERPRETATION. The bound_support record takes an interpretation "
    "{measurement, inference, population_rationale}: what the passage reports in its own terms, which "
    "way the step runs (at_least_the_reported_value, at_most_the_reported_value, "
    "outside_the_reported_range_is_out_of_population, the_heuristic_is_the_line), and why that step "
    "holds for the candidates this task screens. An adjudicator then reads the quote, your declaration "
    "and the rule, and grants the bound or refuses it; a granted bound is recorded as resting on an "
    "interpretation, never as a threshold the source states. An undeclared interpretation is worse "
    "than no cutoff: nobody can grant what nobody has stated, so the cutoff stops scoring and the "
    "criterion ranks instead. A circular justification is no justification -- 'the bound is 90 because "
    "90 is appropriate' is refused before anyone reads it -- and inventing a number no passage states "
    "is still forbidden, interpretation or not: the inference runs from the number the passage gives. "
    "Propose a hard_exclusion where the task or the evidence makes the property a requirement rather "
    "than a preference -- a candidate failing it is unsuitable, not merely worse -- and say so in the "
    "interpretation, because excluding candidates on an interpreted bound is granted separately. "
    "A preference rule without a cited cutoff uses predicate_form ordering: candidates are ranked by the value in "
    "the attribute's direction. "
    "Bind each attribute's evidence_request to one entry of the evidence catalog and fill its parameters. "
    "When one quantity is measured by several catalog entries -- the same measurement curated by two "
    "databases -- declare them together as evidence_requests [{...}, {...}] on one attribute instead of "
    "writing one attribute per database: their values are then pooled under that attribute's aggregation. "
    "A literature route may not be combined with a database route on one attribute. "
    "When that entry states a determination_basis, list it in the attribute's acceptable_determination_bases, "
    "or every value the source returns is set aside and the attribute carries no evidence. "
    "Never name or allude to any specific candidate compound in definitions, rationales, or rules. "
    "Merge duplicates; record what you considered and rejected, with reasons. Recall matters: cover every distinct "
    "property the claims support, across all dimensions."
)

CRITIC_SYSTEM = (
    "You are a blind critic of proposed screening criteria. You see the proposals and the claims they cite, not the "
    "proposer's reasoning. For each proposal run the checks: objective_conformance (does it serve the objective and "
    "constraints?), evidence_support (do the cited quotes actually support the attribute and any cutoff?), "
    "unit_applicability_consistency (units, direction, measurement kind coherent?), counter_evidence_considered, "
    "candidate_symmetric_scrutiny (would it treat all candidates alike, with no hidden preference for a particular "
    "compound?), falsification_test_evaluated (is the falsification test observable?). Every finding must name its "
    "referent: a claim id or a proposal field. Mark severity blocking only for a defect that should stop the "
    "proposal; findings without a referent are not allowed."
)

REVISION_SCHEMA = {
    "type": "object", "required": ["revisions"],
    "properties": {"revisions": {"type": "array", "items": {
        "type": "object", "required": ["index", "action", "reason"],
        "properties": {"index": {"type": "integer"}, "action": {"type": "string", "enum": ["revise", "withdraw"]},
                       "proposal": {"type": ["object", "null"]}, "reason": {"type": "string"}}}}},
}

REVISER_SYSTEM = PROPOSER_SYSTEM + (
    " You are now revising proposals after a blind critique and deterministic validation. For each proposal listed, "
    "either revise it so every material finding is resolved, or withdraw it with the reason. Keep supporting_claim_ids "
    "to claims that actually support the attribute. Do not add new proposals."
)

# Material failures on these checks send a proposal back for one revision; still failing afterwards, it is rejected.
REVISION_CHECKS = ("objective_conformance", "evidence_support", "unit_applicability_consistency",
                   "counter_evidence_considered", "candidate_symmetric_scrutiny")

# WHY acceptable_determination_bases is in this list: it is a validated attribute field (`check_attribute`), and the
# proposer is told to declare it when a bound source returns a basis the defaults exclude. Filtering it out here left
# that instruction impossible to satisfy -- the attribute came back with the identical validator problem after every
# revision, because the declaration was stripped before the check re-read it.
#
# WHY `bound_support` is in this list: a support record is declared for the parameter path it
# supports (§5.4), the proposer is asked for one, and the registry reads it when it computes what
# the criterion needs before it may score. Stripped here, the declaration would never reach the
# record -- a field the schema accepts and nothing downstream reads (§5.3).
#
# WHY `determination_basis_precedence` is in this list: it is a validated attribute field
# (`criteria.check_basis_precedence`) and the only way an attribute may accept a prediction under a
# measurement, so a proposal stripped of it is refused for mixing bases -- the same unsatisfiable
# loop `acceptable_determination_bases` was in before it was added here.
ATTRIBUTE_FIELDS = ("name", "definition", "measurement_kind", "unit", "direction", "acceptable_value_sources",
                    "acceptable_determination_bases", "determination_basis_precedence", "aggregation",
                    "value_transform", "evidence_request", "evidence_requests", "rationale", "bound_support",
                    "existence_semantics", "quantity_id", "aggregation_scope")

# WHY one shared constant: both prompt builders describe the rule schema, and when the description drifts from what
# `check_rule` accepts a proposer spends revisions discovering the real contract. This listed two of the five
# predicate forms and never said that ordering ranks candidates, so a non-ranking rule had no form to reach for.
SCHEMA_BLOCK_FORMS = (
    "Numeric routes for different targets are pooled as raw observations by the current executor; "
    "it cannot compute per-target medians followed by a minimum, spread or ratio. Keep independent "
    "target criteria for those questions. An intentionally pooled raw summary must explicitly declare "
    "attribute.aggregation_scope='pooled_observations', aggregation min|max|median, and a definition "
    "that describes that raw pooling. Do not label a pooled value as a grouped composite.\n"
    "Rule fields: rule_kind (hard_exclusion|preference|exploratory_consideration), predicate_form "
    "(threshold|ordering|range_membership|categorical_membership|qualitative_judgment|recorded_observation); an ordering predicate ranks "
    "candidates, so it is only valid on a preference -- an exploratory_consideration uses qualitative_judgment "
    "or explicitly recorded_observation to preserve a value and its evidence without a comparison or preference score. "
    "recorded_observation requires a null cutoff and none_evidence_insufficient. "
    "cutoff {comparator (>=|<=|>|<|==), value, unit} or null, cutoff_basis "
    "(source_stated_value|none_evidence_insufficient), on_missing/on_inapplicable/on_conflict "
    "(unknown_no_penalty|unknown_blocks_recommendation|route_to_human).\n"
    "Every number a candidate is compared against -- a rule cutoff, a bound inside a value_transform -- carries "
    "one bound_support record, on the rule for its cutoff and on the attribute for a transform bound: "
    "{parameter_path (rule.cutoff.value | attribute.value_transform.bound|low|high), claim_id, source_number, "
    "source_unit, conversion {kind: identity|unit_conversion (factor, from_unit, to_unit)|explicit_derivation "
    "(expression, result)}, statement_kind (states_decision_threshold when the passage states the number as a "
    "requirement | reports_measurement when it reports a measured or observed value or range | provides_heuristic), "
    "applicability_rationale (why it applies to this candidate population)}. The number, the unit and the "
    "arithmetic are checked against the claim; statement_kind and applicability_rationale are your reading and are "
    "recorded as such.\n"
    "Where statement_kind is reports_measurement or provides_heuristic and you still want the number to act as a "
    "cutoff, add to that record interpretation {measurement (what the passage reports, in its own terms), inference "
    "(at_least_the_reported_value | at_most_the_reported_value | "
    "outside_the_reported_range_is_out_of_population | the_heuristic_is_the_line), population_rationale (why that "
    "step holds for the candidates being screened)}. The direction is checked against the comparator the rule "
    "applies and, for a range edge, against the range the claim states; a justification that only restates the "
    "number is refused. Without it the bound cannot be granted and the cutoff will not score.\n")
RULE_FIELDS = ("rule_kind", "predicate_form", "cutoff", "cutoff_basis", "on_missing", "on_inapplicable",
               "on_conflict", "bound_support")


def _excluded(hit: dict[str, Any], case_sources: list[dict[str, Any]]) -> bool:
    return reading.is_case_source(hit, case_sources)


def reading_order(hit: dict[str, Any]) -> tuple[bool, bool, int, int]:
    """Reading order for criterion discovery: a review or a reference entry first, then a document
    whose full text is reachable, then the hits more queries found, then the source's own rank.

    WHY a reference entry counts with the reviews: the genre flags are honest, so a drug monograph
    carries `is_review=False`. With `not is_review` as the only primary key, every monograph sorted
    below every review from every source and the per-dimension document budget never reached one —
    yet the monograph is where a measured quantity is attributable to a named compound.
    """
    return (not (hit.get("is_review") or hit.get("is_reference_entry")),
            not (hit.get("pmcid") or hit.get("source") in ("bookshelf", "uploads")),
            -len(hit.get("found_by", [])), hit.get("best_rank", 0))


# Research breadth and depth when no settings are given: one round, as before settings existed.
DEFAULT_RESEARCH = {"breadth": 5, "depth": 1, "breadth_decay": 0.5, "results_per_query": 10,
                    "max_records_screened": 300, "max_documents": 8, "saturation_k": 3, "saturation_stop": 0.0,
                    "sources": None, "max_content_chars": 60_000}


# WHY the bands move saturation and not only the ceiling: measured on 14 October 2026, `--preset deep`
# allows 200 documents per dimension and enumerate made 19 reader calls. The ceiling was never the
# constraint -- a dimension stops when the share of newly relevant records falls below
# `search.saturation_stop` and when `saturation_k` consecutive documents add nothing. So a band has to
# raise the patience as well as the cap, or asking for more literature changes nothing. They are
# limits on effort, not quotas: a dimension whose evidence genuinely runs dry still stops early, which
# is the point -- padding a run to hit a number buys documents nobody should read.
#
#   papers per dimension, roughly        books a dimension may draw on
#   low    10-50     saturation 0.20     low    1-3
#   mid    50-100    saturation 0.10     mid    3-5
#   high   100-200   saturation 0.05     high   5-10
#   xhigh  200+      saturation 0.02     xhigh  10+
SEARCH_VOLUME = {
    "low":   {"max_documents": 50,  "saturation_stop": 0.20, "saturation_k": 2, "max_records_screened": 300},
    "mid":   {"max_documents": 100, "saturation_stop": 0.10, "saturation_k": 3, "max_records_screened": 600},
    "high":  {"max_documents": 200, "saturation_stop": 0.05, "saturation_k": 5, "max_records_screened": 1200},
    "xhigh": {"max_documents": 400, "saturation_stop": 0.02, "saturation_k": 8, "max_records_screened": 2500},
}
TEXTBOOK_VOLUME = {"low": 3, "mid": 5, "high": 10, "xhigh": 32}


def research_params(settings) -> dict[str, Any]:
    """Research breadth and depth for derivation from resolved settings (core/config.py)."""
    if settings is None:
        return dict(DEFAULT_RESEARCH)
    band = SEARCH_VOLUME[settings["search.volume"]]
    return {"breadth": settings["search.breadth"], "depth": settings["search.depth"],
            "books_per_dimension": TEXTBOOK_VOLUME[settings["textbook.volume"]],
            "breadth_decay": settings["search.breadth_decay"], "results_per_query": settings["search.results_per_query"],
            # An explicitly set ceiling still wins over the band, so `--preset deep` and an explicit
            # `read.max_papers_full_read` are not silently overridden by a volume word.
            "max_documents": max(settings["read.max_papers_full_read"], band["max_documents"]),
            "saturation_k": band["saturation_k"],
            "saturation_stop": min(settings["search.saturation_stop"], band["saturation_stop"]),
            "max_records_screened": max(settings["search.max_records_screened"], band["max_records_screened"]),
            "sources": list(settings["search.sources"]),
            "max_content_chars": settings["read.max_content_chars"]}


def enumerate_dimension(core: Core, broker, roster: ModelRoster, stream_id: str, *, task_context: dict[str, Any],
                        dimension: dict[str, str], cutoff_date: str | None, saturation_k: int | None = None,
                        max_documents: int | None = None, ids: dict | None = None, budget: Any = None,
                        all_dimensions: list[dict[str, str]] | None = None,
                        read_cache: dict[str, list[dict[str, Any]]] | None = None,
                        research: dict[str, Any] | None = None) -> dict[str, Any]:
    """Recall-first enumeration for one dimension: breadth x depth rounds of search and reading.

    Round 0 plans `breadth` queries. Each later round plans queries from what was already
    searched and learned (gaps, alternatives, counter-evidence), with breadth multiplied by
    `breadth_decay`. Reading within a round stops after `saturation_k` consecutive documents
    add no new topic; rounds stop at the document cap, when no new records turn up, or when
    the share of documents adding a new topic falls below `saturation_stop`.
    Returns hints, claims, per-round statistics, the stop reason, and a visibility manifest.
    """
    r = dict(DEFAULT_RESEARCH, **(research or {}))
    if max_documents is not None:
        r["max_documents"] = max_documents
    if saturation_k is not None:
        r["saturation_k"] = saturation_k
    objective = task_context["objective_text"]
    scope = ", ".join(e.get("label") or e.get("identifier", "") for e in task_context.get("scope_entities", []))
    focus = f"{dimension['focus']} as criteria for: {objective}" + (f" (scope: {scope})" if scope else "")
    case_sources = task_context.get("case_source_documents", [])
    all_queries: list[dict[str, str]] = []
    coverage_ids: list[str] = []
    seen: set[str] = set()
    included_all: list[dict[str, Any]] = []
    excluded_all: list[dict[str, Any]] = []
    hints: dict[str, list[str]] = {}
    claims: list[dict[str, Any]] = []
    read_count, rounds, stop_reason = 0, [], "depth_reached"
    unreadable: list[dict[str, Any]] = []
    breadth = float(r["breadth"])
    for level in range(int(r["depth"])):
        queries = reading.plan_queries(core, roster, stream_id, objective_text=objective, focus=focus,
                                       max_queries=max(1, round(breadth)), ids=ids, budget=budget,
                                       searched=[q["query"] for q in all_queries] if level else None,
                                       learned=list(hints)[:40] if level else None)
        all_queries += queries
        hits, coverage_id = reading.search(core, broker, stream_id, [q["query"] for q in queries], cutoff_date=cutoff_date,
                                           limit_per_query=r["results_per_query"], ids=ids, budget=budget,
                                           sources=r["sources"])
        coverage_ids.append(coverage_id)
        room = max(0, int(r["max_records_screened"]) - len(seen))
        fresh = [h for h in hits if reading._key(h) not in seen][:room]
        seen.update(reading._key(h) for h in fresh)
        included = [h for h in fresh if not _excluded(h, case_sources)]
        excluded_all += [h for h in fresh if _excluded(h, case_sources)]
        included.sort(key=reading_order)
        included_all += included
        stale, documents, contributing, new_topics = 0, 0, 0, 0
        for hit in included:
            if read_count >= r["max_documents"] or stale >= r["saturation_k"]:
                break
            key = reading._key(hit)
            if read_cache is not None and key in read_cache:
                found = read_cache[key]          # read once across dimensions; its claims cover every dimension
            else:
                document = reading.read(core, broker, stream_id, hit, ids=ids, budget=budget, cutoff_date=cutoff_date)
                if document is None:
                    continue
                try:
                    found = reading.extract_claims(core, roster, stream_id, document, {
                        "purpose": "criterion_discovery", "objective_text": objective + (f" Scope: {scope}." if scope else ""),
                        "dimensions": all_dimensions or [dimension], "attribute": None, "candidate": None}, ids=ids, budget=budget,
                        max_chars=r["max_content_chars"])
                except ModelError as error:
                    # WHY one document may fail without ending the round: a reasoning provider
                    # occasionally answers in prose, and `call_role` raises once its repairs are
                    # spent. Measured on 14 October 2026 against DeepSeek: this exact call killed a
                    # derivation after 1.5 hours and 312 admitted claims, and the same class of
                    # failure in `refine_stage` killed the run before it. A document whose claims
                    # cannot be extracted is a document that contributes nothing -- which is what an
                    # unreadable document already does two lines above -- so it is skipped and
                    # counted. A budget refusal still propagates: that is the run being told to stop.
                    if error.error_class == "quota_exhausted":
                        raise
                    unreadable.append({"key": key, "reason": f"{error.error_class}: {error}"[:160]})
                    continue
                if read_cache is not None:
                    read_cache[key] = found
            read_count += 1
            documents += 1
            new = 0
            for claim in found:
                if claim["admission_state"] != "admitted":
                    continue
                claims.append(claim)
                hint = reading.normalize_for_match(claim.get("attribute_hint") or claim["normalized_statement"])[:80]
                if hint not in hints:
                    new += 1
                hints.setdefault(hint, []).append(claim["claim_id"])
            contributing += 1 if new else 0
            new_topics += new
            stale = 0 if new else stale + 1
        novelty = contributing / documents if documents else 0.0
        rounds.append({"round": level, "queries": len(queries), "new_records": len(fresh), "documents_read": documents,
                       "new_topics": new_topics, "novelty": round(novelty, 3), "coverage_id": coverage_id})
        if read_count >= r["max_documents"]:
            stop_reason = "document_cap"
            break
        if not fresh:
            stop_reason = "no_new_records"
            break
        if documents and novelty < r["saturation_stop"]:
            stop_reason = "saturated"
            break
        breadth *= r["breadth_decay"]
    manifest = {"actor": "derivation", "subject": dimension["dimension"], "catalog_size": len(seen),
                "included_ids": [reading._key(h) for h in included_all],
                "excluded": [{"id": reading._key(h), "omitted_reason": "case_source_document"} for h in excluded_all]
                + [{"id": "historical_criteria_intake", "omitted_reason": "evaluator_only_artifact"}],
                "content_hash": None, "recorded_at": utc_now()}
    manifest_id = core.artifacts.put("visibility_manifest", manifest)
    return {"dimension": dimension["dimension"], "queries": all_queries, "coverage_id": coverage_ids[0] if coverage_ids else None,
            "coverage_ids": coverage_ids, "manifest_id": manifest_id, "documents_read": read_count,
            # Documents whose claims could not be extracted, so a reader can tell a dimension that
            # found little from one whose evidence was lost to a provider that answered in prose.
            "documents_unreadable": unreadable,
            "saturated": stop_reason in ("saturated", "no_new_records"),
            "rounds": rounds, "stop_reason": stop_reason, "research": {k: v for k, v in r.items()},
            "hints": hints, "claims": claims}


def _claims_block(claims: list[dict[str, Any]]) -> str:
    lines = []
    for claim in claims:
        lines.append(json.dumps({"claim_id": claim["claim_id"], "attribute_hint": claim.get("attribute_hint"),
                                 "quote": claim["location"]["quoted_span"], "value": claim.get("value"),
                                 "range": [claim.get("value_low"), claim.get("value_high")]
                                 if claim.get("value_low") is not None or claim.get("value_high") is not None else None,
                                 "unit": claim.get("unit"),
                                 "source": claim["source_ref"], "basis": claim["determination_basis"]}, ensure_ascii=False))
    return "\n".join(lines)


def _route_output_problems(attribute: dict[str, Any], request: dict[str, Any],
                           entry: dict[str, Any]) -> list[str]:
    """Check a catalog's fixed output against the assessor's executable type/unit contract.

    Free-form literature units and catalogs without a fixed output declaration remain unknown
    here. A registered conversion is directional, exactly as it is in `usable_claims`.
    """
    units = entry.get("units")
    if not isinstance(units, dict) or not units:
        return []
    parameters = request.get("parameters") or {}
    selectors = [key for key in ("property", "endpoint", "field") if key in parameters
                 and key in (entry.get("parameters") or {})]
    if selectors:
        selected = parameters[selectors[0]]
        if not isinstance(selected, str) or selected not in units:
            return [f"schema: route {entry['capability']}/{entry['question_kind']} has no declared output "
                    f"for {selectors[0]}={selected!r}"]
        returned_unit = units[selected]
    elif len(set(units.values())) == 1:
        returned_unit = next(iter(units.values()))
    else:
        # Several possible outputs without an explicit selector: do not guess which was meant.
        return []
    route = f"{entry['capability']}/{entry['question_kind']}"
    if attribute.get("measurement_kind") == "quantitative":
        if returned_unit is None:
            return [f"schema: route {route} returns unitless categorical values; no executable numeric "
                    f"aggregation converts them to {attribute.get('unit')!r} (including a target count)"]
        target_unit = attribute.get("unit")
        if assessor.canonical_unit(returned_unit) != assessor.canonical_unit(target_unit) \
                and assessor.unit_conversion(returned_unit, target_unit) is None:
            return [f"units: route {route} returns {returned_unit!r}, but the attribute declares {target_unit!r}; "
                    "the assessor has no registered conversion in that direction"]
    elif attribute.get("measurement_kind") == "categorical" and returned_unit is not None:
        return [f"schema: route {route} returns numeric values in {returned_unit!r}; a categorical attribute "
                "has no declared executable categorical projection for that output"]
    return []


def validate_proposal(proposal: dict[str, Any], *, claims_by_id: dict[str, dict[str, Any]],
                      reference_labels: list[str], catalog: list[dict[str, Any]]) -> list[str]:
    """Deterministic validator findings for one proposal (empty list = valid)."""
    problems = []
    attribute, rule = proposal.get("attribute", {}), proposal.get("rule", {})
    try:
        criteria.check_attribute(attribute)
        criteria.check_rule(rule, attribute)
    except criteria.InvariantViolation as violation:
        problems.append(f"{violation.finding_class}: {violation}")
    cited = proposal.get("supporting_claim_ids", [])
    missing = [c for c in cited if c not in claims_by_id]
    if not cited:
        problems.append("evidence_support: no supporting claims cited")
    if missing:
        problems.append(f"evidence_support: cited claims not in the ledger {missing}")
    # Every number this proposal would compare a candidate against, against the claims it cites
    # (`core/bound_support.py`, design §5.4). WHY it replaces the count of cited claims carrying *a*
    # value: that check passed a `source_stated_value` cutoff of 90 whose cited claim stated 30 (R4),
    # because the presence of a numeric claim is not support for a particular number.
    support = bound_support.validate(attribute, rule, claims=[claims_by_id[c] for c in cited if c in claims_by_id])
    problems += bound_support.messages(support)
    # Every route is bound and checked, not just the first: an attribute may read one quantity from
    # two databases, and an unbound second route would be a tool call nobody declared.
    routes = criteria.evidence_routes(attribute)
    for request in routes:
        request = request if isinstance(request, dict) else {}
        entry = next((e for e in catalog if e["capability"] == request.get("capability")
                      and e["question_kind"] == request.get("question_kind")), None)
        if entry is None:
            problems.append(f"schema: evidence route {request.get('capability')}/{request.get('question_kind')} "
                            f"is not bound to a catalog entry")
            continue
        problems += _route_output_problems(attribute, request, entry)
        if len(routes) > 1 and entry.get("evidence_kind") \
                and entry["evidence_kind"] not in set(attribute.get("acceptable_value_sources") or ()):
            # Checked only for a pooled attribute, because that is where the mismatch hides: a single
            # route whose kind the attribute does not accept leaves the cell empty, which reads as
            # absence, while one of two leaves the cell scored on half the evidence it declares and
            # says nothing about the half that was dropped.
            problems.append(f"evidence_support: route {entry['capability']}/{entry['question_kind']} returns "
                            f"{entry['evidence_kind']} claims and acceptable_value_sources "
                            f"{attribute.get('acceptable_value_sources')} excludes that kind, so this route would "
                            f"contribute nothing while the attribute's other routes score the cell")
        if entry.get("determination_basis"):
            # The source states what its records are. An attribute that does not accept that basis has
            # every value it receives set aside at assessment time, which reads as "no data" rather than
            # as a mistake, so the pairing is refused here instead.
            accepted = list(attribute.get("acceptable_determination_bases") or assessor.DEFAULT_DETERMINATION_BASES)
            if entry["determination_basis"] not in accepted:
                problems.append(f"evidence_support: the bound source {entry['capability']}/{entry['question_kind']} "
                                f"returns {entry['determination_basis']} records and acceptable_determination_bases "
                                f"{accepted} excludes that basis, so every value it returns would be set aside and "
                                f"the attribute would carry no evidence")
    if criteria.is_literature_bound(attribute) and not (attribute.get("measurement_kind") == "quantitative"
                                                        and attribute.get("unit")):
        problems.append("schema: literature evidence yields numbers with units; a literature-bound attribute must be "
                        "quantitative with a unit")
    text = json.dumps({k: attribute.get(k) for k in ("name", "definition", "rationale")} | {"rule": rule}, ensure_ascii=False)
    if reference_labels and reading.names_entity(reference_labels, text):
        problems.append("reference_candidate_scan: a proposal names the disclosed reference outcome")
    return problems


def _normalize_proposal(proposal: dict[str, Any]) -> dict[str, Any]:
    attribute = {k: v for k, v in proposal.get("attribute", {}).items() if k in ATTRIBUTE_FIELDS}
    rule = {k: v for k, v in proposal.get("rule", {}).items() if k in RULE_FIELDS}
    if rule.get("cutoff") in ({}, None) or rule.get("cutoff_basis") == "none_evidence_insufficient":
        rule["cutoff"] = None if rule.get("cutoff_basis") == "none_evidence_insufficient" else rule.get("cutoff")
    return dict(proposal, attribute=attribute, rule=rule)


def objective_criteria(core: Core, task_id: str, *, templates, by: dict[str, Any]) -> list[dict[str, Any]]:
    """Criteria the task itself mandates (required scope entities, hard constraints), built by adapter templates.

    `templates(task_context)` returns [{"attribute", "rule", "source_field"}]. Each is proposed with
    `derived_from: task_context` and its source field, skipping any whose evidence key is already registered.
    Templates explicitly setting `preserve_task_binding` deduplicate by evidence plus task field instead,
    so a required observation cannot absorb a literal hard constraint on the same property.
    Hard exclusions among them still need an expert decision (trigger table).
    """
    from . import task as task_mod
    context = task_mod.get(core, task_id)
    registered = criteria.registered_attributes(core, task_id)
    existing = {criteria.evidence_key(a) for a in registered}
    existing_bindings = {(criteria.evidence_key(a), (a.get("derived_from") or {}).get("field"))
                         for a in registered if criteria.is_task_mandated(a)}
    who = make_actor("system", "objective-criteria", "adapter_template")
    added = []
    for item in templates(context):
        key = criteria.evidence_key(item["attribute"])
        # A generic scope observation and a literal hard constraint may read
        # the same property. Preserve both task fields: measurement-only
        # deduplication must never silently discard the user's hard requirement.
        duplicate = ((key, item["source_field"]) in existing_bindings if item.get("preserve_task_binding")
                     else key in existing)
        if duplicate:
            continue
        attribute = dict(item["attribute"], derived_from={"task_context": f"{task_id}@v{context['version']}",
                                                           "field": item["source_field"]})
        attr_ref, rule_ref = criteria.propose(core, task_id, attribute, item["rule"], by=who)
        existing.add(key)
        existing_bindings.add((key, item["source_field"]))
        added.append({"attribute_ref": attr_ref, "rule_ref": rule_ref, "name": attribute["name"],
                      "rule_kind": item["rule"]["rule_kind"], "source_field": item["source_field"]})
    return added


def derive(core: Core, broker, roster: ModelRoster, task_id: str, *, dimensions: list[dict[str, str]],
           catalog: list[dict[str, Any]], by: dict[str, Any], cutoff_date: str | None = None, saturation_k: int = 3,
           max_documents: int | None = None, budget: Any = None, stream_id: str | None = None, templates=None,
           research: dict[str, Any] | None = None) -> dict[str, Any]:
    """Run derivation for a task; accepted proposals enter the registry and the review queue.

    Objective-mandated criteria (adapter `templates`) are registered first; literature-derived proposals
    that duplicate a registered attribute are recorded as duplicates. Proposals still disputed after one
    revision enter the registry with a review item showing the open findings; the expert decides.
    """
    from . import task as task_mod
    mandated = objective_criteria(core, task_id, templates=templates, by=by) if templates else []
    context = task_mod.get(core, task_id)
    stream_id = stream_id or task_id
    ids = {"task_id": task_id}
    read_cache: dict[str, list[dict[str, Any]]] = {}
    enumerations = [enumerate_dimension(core, broker, roster, stream_id, task_context=context, dimension=d,
                                        cutoff_date=cutoff_date, saturation_k=saturation_k, max_documents=max_documents,
                                        ids=ids, budget=budget, all_dimensions=dimensions, read_cache=read_cache,
                                        research=research)
                    for d in dimensions]
    claims = list({c["claim_id"]: c for e in enumerations for c in e["claims"]}.values())
    claims_by_id = {c["claim_id"]: c for c in claims}
    reference_labels = [label for seed in context.get("seed_candidates", []) if seed.get("is_reference_outcome")
                        for label in [seed["candidate_ref"], *seed.get("aliases", [])]]
    scope = json.dumps(context.get("scope_entities", []), ensure_ascii=False)
    prompt = (f"Objective: {context['objective_text']}\nConstraints: {json.dumps(context.get('constraints', []), ensure_ascii=False)}\n"
              f"Scope entities: {scope}\nDimensions: {', '.join(d['dimension'] for d in dimensions)}\n"
              f"Criteria already registered from the task itself (do not duplicate them): "
              f"{json.dumps([a['name'] for a in criteria.registered_attributes(core, task_id)], ensure_ascii=False)}\n\n"
              f"Evidence catalog (bind each attribute's evidence_request to one entry):\n{json.dumps(catalog, ensure_ascii=False, indent=1)}\n\n"
              f"Attribute fields: name, definition, measurement_kind (quantitative|ordinal|categorical|qualitative_determination), "
              f"unit, direction (higher_better|lower_better|within_range|target_value|non_directional|undetermined), "
              f"acceptable_value_sources (evidence kinds: curated_measurement, database_entry, model_prediction, "
              f"peer_reviewed, preprint, reference_text, tertiary_reference, user_supplied_document), "
              f"acceptable_determination_bases (defaults to measured and derived), "
              f"determination_basis_precedence when one quantity is read from sources of different bases and the "
              f"weaker one is only to fill gaps -- [\"measured\", \"predicted\"] uses the measurement where "
              f"there is one and the prediction only where there is none, never both in one aggregate; it must "
              f"list every accepted basis exactly once and may not put predicted first, "
              f"value_transform when the attribute is about a derived quantity rather than the value the source "
              f"returns -- {{kind: excess_above|shortfall_below|distance_outside_band, bound or low and high, "
              f"basis, source_refs}}; without it the raw value is what gets ranked, however the definition "
              f"describes the quantity, "
              f"aggregation (max|min|consensus), evidence_request {{capability, question_kind, identifier_scheme, parameters}} "
              f"-- or evidence_requests [{{...}}, {{...}}] when one quantity is read from several catalog entries, "
              f"rationale.\n"
              + SCHEMA_BLOCK_FORMS
              + f"\nClaims ({len(claims)}):\n{_claims_block(claims)}")
    proposer = call_role(core, roster, stream_id, ModelRequest(
        role="proposer", system=PROPOSER_SYSTEM, messages=[{"role": "user", "content": prompt}],
        response_schema=PROPOSAL_SCHEMA, max_tokens=12000, metadata={"question": "propose criteria"}), ids=ids, budget=budget)
    proposals = [_normalize_proposal(p) for p in proposer.data["proposals"]]
    rejected = list(proposer.data["considered_and_rejected"])

    def run_validator(items: dict[int, dict[str, Any]]) -> dict[int, list[str]]:
        return {i: validate_proposal(p, claims_by_id=claims_by_id, reference_labels=reference_labels, catalog=catalog)
                for i, p in items.items()}

    def run_critic(items: dict[int, dict[str, Any]], prior: list[dict[str, Any]] | None = None):
        critique_input = [{"index": i, "attribute": p["attribute"], "rule": p["rule"],
                           "supporting_claim_ids": p["supporting_claim_ids"], "falsification_test": p["falsification_test"]}
                          for i, p in items.items()]
        cited = {c for p in items.values() for c in p["supporting_claim_ids"] if c in claims_by_id}
        revision_note = ("\n\nThis is a revision check. Your earlier findings on these proposals were:\n"
                         + json.dumps(prior, ensure_ascii=False, indent=1)) if prior else ""
        response = call_role(core, roster, stream_id, ModelRequest(
            role="critic", system=CRITIC_SYSTEM, response_schema=CRITIQUE_SCHEMA, max_tokens=8000,
            messages=[{"role": "user", "content": f"Objective: {context['objective_text']}\n\nProposals:\n"
                       f"{json.dumps(critique_input, ensure_ascii=False, indent=1)}\n\nCited claims:\n"
                       f"{_claims_block([claims_by_id[c] for c in sorted(cited)])}{revision_note}"}],
            metadata={"question": "revision check" if prior else "critique proposals"}), ids=ids, budget=budget)
        return response, [f for f in response.data["findings"] if f.get("referent")]

    def classify(index: int, problems: list[str], findings: list[dict[str, Any]]) -> str:
        mine = [f for f in findings if f["proposal_index"] == index and f["verdict"] == "fail"]
        if problems or any(f.get("severity") == "blocking" for f in mine):
            return "blocked"
        if any(f["check"] in REVISION_CHECKS and f.get("severity", "material") == "material" for f in mine):
            return "revise"
        return "accept"

    items = dict(enumerate(proposals))
    validator = run_validator(items)
    critic, findings = run_critic(items)
    status = {i: classify(i, validator[i], findings) for i in items}
    to_revise = {i: p for i, p in items.items() if status[i] in ("revise", "blocked")}
    revision_record: list[dict[str, Any]] = []
    if to_revise:
        notes = [{"index": i, "attribute": p["attribute"], "rule": p["rule"],
                  "supporting_claim_ids": p["supporting_claim_ids"], "expected_change": p["expected_change"],
                  "falsification_test": p["falsification_test"], "validator_problems": validator[i],
                  "critic_findings": [f for f in findings if f["proposal_index"] == i and f["verdict"] == "fail"]}
                 for i, p in to_revise.items()]
        reviser = call_role(core, roster, stream_id, ModelRequest(
            role="proposer", system=REVISER_SYSTEM, response_schema=REVISION_SCHEMA, max_tokens=12000,
            messages=[{"role": "user", "content": prompt + "\n\nProposals to revise or withdraw:\n"
                       + json.dumps(notes, ensure_ascii=False, indent=1)}],
            metadata={"question": "revise proposals"}), ids=ids, budget=budget)
        revised: dict[int, dict[str, Any]] = {}
        for revision in reviser.data["revisions"]:
            index = revision["index"]
            if index not in to_revise:
                continue
            revision_record.append({"index": index, "action": revision["action"], "reason": revision["reason"]})
            if revision["action"] == "revise" and revision.get("proposal"):
                merged = dict(to_revise[index], **revision["proposal"])
                revised[index] = _normalize_proposal(merged)
        for index in to_revise:
            if index not in revised:
                status[index] = "withdrawn"
        if revised:
            validator.update(run_validator(revised))
            prior = [f for f in findings if f["proposal_index"] in revised and f["verdict"] == "fail"]
            critic, recheck = run_critic(revised, prior)
            findings = [f for f in findings if f["proposal_index"] not in revised] + recheck
            for index, proposal in revised.items():
                items[index] = proposal
                after = classify(index, validator[index], findings)
                status[index] = "accept" if after == "accept" else "unresolved_after_revision"
    accepted = []
    who = make_actor("agent", f"proposer:{proposer.model_id}", "proposer", model_family=roster.adapter("proposer").record.provider_family)
    registered_keys = {criteria.evidence_key(a) for a in criteria.registered_attributes(core, task_id)}
    disputed = []
    for index, proposal in items.items():
        mine = [f for f in findings if f["proposal_index"] == index]
        if status[index] == "accept" and criteria.evidence_key(proposal["attribute"]) in registered_keys:
            status[index] = "duplicate_of_registered"
        if status[index] not in ("accept", "unresolved_after_revision") or (status[index] == "unresolved_after_revision"
                                                                              and validator[index]):
            rejected.append({"attribute": proposal["attribute"].get("name"), "validator": validator[index],
                             "critic": [f for f in mine if f["verdict"] == "fail"], "rejection_reason": status[index]})
            continue
        attribute = dict(proposal["attribute"], rationale=proposal["attribute"].get("rationale", ""),
                         supporting_claim_refs=proposal["supporting_claim_ids"],
                         derived_from={"proposal_request": proposer.request_id, "critique_request": critic.request_id})
        rule = dict(proposal["rule"], expected_change=proposal["expected_change"],
                    falsification_test=proposal["falsification_test"],
                    dissent=[f for f in mine if f["verdict"] == "fail"])
        if criteria.evidence_key(attribute) in registered_keys:
            rejected.append({"attribute": attribute["name"], "validator": [], "critic": [], "rejection_reason": "duplicate_of_registered"})
            continue
        dispute = None
        if status[index] == "unresolved_after_revision":
            dispute = {"open_critic_findings": [f for f in mine if f["verdict"] == "fail"],
                       "proposal_request": proposer.request_id, "critique_request": critic.request_id}
        attr_ref, rule_ref = criteria.propose(
            core, task_id, attribute, rule, by=who, dispute=dispute,
            support=bound_support.validate(attribute, rule, claims=[claims_by_id[c] for c in
                                                                    proposal["supporting_claim_ids"]
                                                                    if c in claims_by_id]))
        registered_keys.add(criteria.evidence_key(attribute))
        entry = {"attribute_ref": attr_ref, "rule_ref": rule_ref, "name": attribute["name"],
                 "rule_kind": rule["rule_kind"], "critic_findings": mine}
        (disputed if dispute else accepted).append(entry)
    record = {"task_id": task_id, "dimensions": [{k: e[k] for k in ("dimension", "documents_read", "saturated",
                                                                      "coverage_id", "manifest_id")}
                                                 | {"n_hints": len(e["hints"]), "n_claims": len(e["claims"])} for e in enumerations],
              "mandated": mandated, "accepted": accepted, "disputed": disputed,
              "considered_and_rejected": rejected, "revisions": revision_record,
              "proposer_model": proposer.model_id,
              "critic_model": critic.model_id,
              "independence": {"proposer_family": roster.adapter("proposer").record.provider_family,
                               "critic_family": roster.adapter("critic").record.provider_family,
                               "same_adapter": roster.roles.get("proposer") == roster.roles.get("critic"),
                               "saw_proposer_rationale": False}}
    record["artifact_id"] = core.artifacts.put("derivation_record", record)
    return record
